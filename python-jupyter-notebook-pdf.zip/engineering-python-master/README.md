# Engineering Python

Welcome to Engineering Python. This is a Python programming course for engineers.

This GitHub repository hosts the Jupyter Notebooks and Python source code for the open course on YouTube (http://youtube.com/yongtwang).

A tutorial on how to use these course materials is in this YouTube video: [02C Course Materials and Jupyter Notebook](https://youtu.be/W0rf--MI2m4).
